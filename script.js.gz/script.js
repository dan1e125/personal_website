var translations={en:{documentTitle:'Daniel Ordonez Arango | Penetration Tester',metaDescription:'Freelance penetration tester for startups and SMBs. Web app, Active Directory & AI/LLM security. HTB Top 1%, 658 targets. Remote-first, clear deliverables.',ogTitle:'Daniel Ordonez Arango | Penetration Tester',ogDescription:'Freelance pentester for startups and SMBs. Web app, AD & AI/LLM security testing. HTB Top 1%, 658 targets. Remote engagements, clear reporting.',selectors:{'.brand-block .eyebrow':'Cybersecurity Portfolio','.topnav a[href="#about"]':'About','.topnav a[href="#experience"]':'Experience','.topnav a[href="#certifications"]':'Certifications','.topnav a[href="#contact"]':'Contact','.hero-copy .lead':'I help startups and SMBs find exploitable vulnerabilities before attackers do, delivering findings your dev team can actually fix.','.hero-copy .spec-item:nth-child(1) span':'Web Pentest','.hero-copy .spec-item:nth-child(2) span':'Networks','.hero-copy .spec-item:nth-child(3) span':'Active Directory','.hero-copy .spec-item:nth-child(4) span':'Privilege Escalation','.hero-copy .spec-item:nth-child(5) span':'AI / LLM','.hero-actions .button.primary':'Request a free scoping call','.hero-actions .button.gold[href="daniel_cv_new.pdf"]':'View original CV','.hero-actions .button.gold[href="htb-academy-student-transcript.pdf"]':'Verified by HTB Academy','.quick-stats li:nth-child(1) span':'HTB paths completed','.quick-stats li:nth-child(2) span':'Targets compromised','.quick-stats li:nth-child(3) span':'HTB ranking',
'.avail-text':'Available for engagements','.terminal-label':'daniel@portfolio:~$ ./profile_scan','.status-grid div:nth-child(1) span':'Status','.status-grid div:nth-child(1) strong':'ACTIVE','.status-grid div:nth-child(2) span':'Focus','.status-grid div:nth-child(2) strong':'PENTEST','.status-grid div:nth-child(3) span':'Mode','.status-grid div:nth-child(3) strong':'REMOTE','.status-grid div:nth-child(4) span':'Coverage','.status-grid div:nth-child(4) strong':'WEB / NET / SYS','.status-grid div:nth-child(5) span':'Availability','.status-grid div:nth-child(5) strong':'OPEN','.status-grid div:nth-child(6) span':'Languages','.status-grid div:nth-child(6) strong':'EN / ES','#experience .section-heading .section-tag':'[ PROFESSIONAL EXPERIENCE ]','#experience .section-heading h3':'Background & Training','#experience .timeline-item:nth-child(1) .role':'Full-Stack Developer & Security Specialist · Ongoing','#experience .timeline-item:nth-child(1) .detail-list li:nth-child(1)':'Web application development using PHP, JavaScript and Node.js with security integrated from the start.','#experience .timeline-item:nth-child(1) .detail-list li:nth-child(2)':'Network and application security — hardening, vulnerability assessments and secure architecture decisions.','#experience .timeline-item:nth-child(1) .detail-list li:nth-child(3)':'Linux server administration — deployment, configuration and maintenance of production environments.','#experience .timeline-item:nth-child(2) .role':'Offensive Security Training · 2025','#experience .timeline-item:nth-child(2) .detail-list li:nth-child(1)':'Completed full penetration testing methodology covering web apps, networks and Active Directory through the CPTS path.','#experience .timeline-item:nth-child(2) .detail-list li:nth-child(2)':'Covered advanced server-side and client-side web exploitation techniques through the CWEE path.','#experience .timeline-item:nth-child(2) .detail-list li:nth-child(3)':'Trained in scoping, methodology and professional engagement documentation.','#certifications article:nth-child(1) .section-tag':'[ EDUCATION / CERTIFICATIONS ]','#certifications .training-section:nth-of-type(1) .section-tag':'[ HTB Job Role & Skills Paths Completed ]','.path-card:nth-child(1) span:last-child':'Web recon, authentication flaws, API exploitation and OWASP-aligned methodology.','.path-card:nth-child(2) span:last-child':'End-to-end methodology: recon, exploitation, post-exploitation, lateral movement and reporting.','.path-card:nth-child(3) span:last-child':'Threat detection, DFIR, incident response and SOC analysis procedures.','.path-card:nth-child(4) span:last-child':'Practical foundations covering both attack and defense disciplines.','.path-card:nth-child(5) strong':'Active Directory Enumeration','.path-card:nth-child(5) span:last-child':'In-depth AD enumeration techniques, tools and attack surface mapping. Hard difficulty path.','.path-card:nth-child(6) strong':'Information Security Foundations','.path-card:nth-child(6) span:last-child':'Core InfoSec concepts: networking, cryptography, pentesting methodology and career foundations.','.path-card:nth-child(7) strong':'SOC Analyst Prerequisites','.path-card:nth-child(7) span:last-child':'Prerequisite knowledge for SOC operations — security fundamentals and threat analysis concepts.','.path-card:nth-child(8) strong':'Operating System Fundamentals','.path-card:nth-child(8) span:last-child':'Windows and Linux internals, administration and hardening in line with security best practices.','.path-card:nth-child(9) strong':'Local Privilege Escalation','.path-card:nth-child(9) span:last-child':'Manual and tool-assisted privilege escalation techniques on Windows and Linux systems.','.path-card:nth-child(10) strong':'Intro to Binary Exploitation','.path-card:nth-child(10) span:last-child':'Buffer overflows, shellcode and exploit scripting. Hard difficulty path.','.path-card:nth-child(11) strong':'Basic Toolset','.path-card:nth-child(11) span:last-child':'Core offensive security tools and their practical application across various scenarios.','.path-card:nth-child(12) strong':'Cracking into Hack The Box','.path-card:nth-child(12) span:last-child':'First guided HTB machine walkthrough — bridging academy knowledge and real-world labs.','.cert-group:nth-child(1) .subsection-label':'External cybersecurity studies','#about article:nth-child(1) p:nth-of-type(2)':'I started as a full-stack developer. That background changes how I test — I know how applications are built, which means I know where developers leave gaps. I pair that with offensive security training across the full attack surface: web exploitation, Active Directory attacks, network pivoting and privilege escalation. Every engagement ends with a report your team can actually act on.','#contact h3':'Get in touch','#cg-profiles':'Online profiles','.contact-intro':'Available for remote engagements worldwide. Response within 24h. The first call costs nothing — we define scope, timeline and fit before any agreement.','.contact-card-phone-title':'Phone','.contact-card-phone-copy':'Direct call — fastest response','.cg-li-title':'LinkedIn','.cg-li-desc':'Professional profile and networking','.cg-gh-title':'GitHub','.cg-gh-desc':'Code, projects and technical footprint','footer a[href="#main"]':'↑ Back to top','.contact-form-card .section-tag':'[ SEND A MESSAGE ]','.cf-heading':'Direct message','label[for="cf-name"]':'Name','label[for="cf-email"]':'Email','label[for="cf-message"]':'Message','.cf-btn-text':'Send message','.topnav a[href="#services"]':'Services','.topnav a[href="#quote"]':'Pricing','#process-heading':'From first contact to final report','#process-copy':'A straightforward engagement cycle designed to minimize disruption and maximize actionable output. Most engagements complete in 1–2 weeks from scoping call to final report.','#process-step1-title':'Scoping Call','#process-step1-desc':'Free 30-minute call to understand your environment, define targets and agree on rules of engagement. No commitment required.','#process-step2-title':'Proposal & NDA','#process-step2-desc':'You receive a written proposal with scope, timeline, methodology and fixed price. NDA signed before any work begins.','#process-step3-title':'Engagement','#process-step3-desc':'Active testing phase. You get progress updates throughout. Any critical findings are reported immediately — no waiting for the final report.','#process-step4-title':'Report & Re-test','#process-step4-desc':'Detailed PDF report with risk ratings, proof-of-concept and remediation steps. Free re-test included to verify fixes.','.topnav a[href="#process"]':'Process','#services-tag':'[ SERVICES ]','#services-heading':'Services','#services-copy':'Remote engagements, clear deliverables, and findings your team can act on.','#svc-web-title':'Web Application Pentest','#svc-web-desc':'Find exploitable vulnerabilities in your app before a breach does. OWASP-aligned manual testing with a written report your team can act on immediately.','#svc-ad-title':'Active Directory Pentest','#svc-ad-desc':'Identify attack paths through your internal network before a threat actor does. BloodHound mapping, credential attacks, and a clear remediation roadmap.','#svc-va-desc':'Automated + manual scan of your attack surface with validated findings and a prioritized remediation report. Lower-cost entry point before a full pentest.','#svc-ai-desc':'Identify prompt injection, data leakage, and model manipulation risks in your AI-powered applications before they reach production.','#quote-heading':'Price your engagement in 60 seconds','#quote-copy':'Fill in the details below to get an instant price range. A formal proposal will be sent after a scoping call.','#ql-service':'Service','#ql-scope':'Scope size','#ql-complexity':'Complexity','#ql-tbox':'Testing type','#ql-addons':'Add-ons','#about article:nth-child(1) .section-tag':'[ ABOUT ]','#about-heading':'Background','#contact .section-tag':'[ CONTACT ]','#qc-main-cta':'Book a free scoping call →','.hero-copy h2':'Penetration tester specialized in web apps & Active Directory.','.service-cta':'Get a quote →'},placeholders:{'#cf-name':'Your name','#cf-email':'your@email.com','#cf-message':'Describe the engagement or project...'},
  formMessages:{
    requiredFields:'Please fill in all fields.',
    invalidEmail:'Please enter a valid email address.',
    success:'✓ Message sent! I will get back to you within 24 hours.',
    submitFailed:'Submission failed. Please try again.',
    networkError:'Network error. Please try again or use the email channel.'
  },terminalLines:['> Scanning operator profile...','> [✓] Services: Web · AD · AI/LLM · VA','> [✓] Mode: REMOTE · Available','> [✓] Report: EN / ES · Actionable'],},es:{
  documentTitle:'Daniel Ordonez Arango | Pentester',
  metaDescription:'Pentester freelance para startups y PYMEs. Seguridad en apps web, Active Directory e IA/LLM. HTB Top 1%, 658 objetivos. Trabajo remoto, reportes claros.',
  ogTitle:'Daniel Ordonez Arango | Pentester',
  ogDescription:'Portafolio de seguridad ofensiva enfocado en penetration testing, analisis defensivo, calidad de reportes y superficies de ataque modernas.',
  selectors:{
    // ── Header ──
    '.brand-block .eyebrow':'Portafolio de Ciberseguridad',
    '.topnav a[href="#services"]':'Servicios',
    '.topnav a[href="#about"]':'Sobre mi',
    '#about-heading':'Sobre mí',
    '.topnav a[href="#process"]':'Proceso',
    '.topnav a[href="#quote"]':'Precios',
    
    '.topnav a[href="#experience"]':'Experiencia',
    
    '.topnav a[href="#certifications"]':'Certificaciones',
    '.topnav a[href="#contact"]':'Contacto',

    // ── Hero ──
    
    '.hero-copy h2':'Pentester especializado en apps web y Active Directory.',
    '.hero-copy .lead':'Ayudo a startups y pymes a encontrar vulnerabilidades explotables antes que los atacantes — hallazgos que tu equipo puede corregir de inmediato.',
    '.hero-copy .spec-item:nth-child(1) span':'Pentest Web',
    '.hero-copy .spec-item:nth-child(2) span':'Redes',
    '.hero-copy .spec-item:nth-child(3) span':'Active Directory',
    '.hero-copy .spec-item:nth-child(4) span':'Escalada de privilegios',
    '.hero-copy .spec-item:nth-child(5) span':'IA / LLM',
    '#process-heading':'Del primer contacto al informe final','#process-copy':'Un ciclo de trabajo claro, diseñado para minimizar interrupciones y maximizar resultados accionables. La mayoría de los proyectos se completan en 1–2 semanas desde la llamada de alcance hasta el informe final.','#process-step1-title':'Llamada de alcance','#process-step1-desc':'Llamada gratuita de 30 min para definir objetivos y reglas de engagement. Sin compromiso.','#process-step2-title':'Propuesta y NDA','#process-step2-desc':'Recibes propuesta escrita con alcance, cronograma, metodología y precio fijo. NDA firmado antes de iniciar.','#process-step3-title':'Engagement','#process-step3-desc':'Fase de pruebas activas con actualizaciones de progreso. Hallazgos críticos reportados de inmediato.','#process-step4-title':'Reporte y re-test','#process-step4-desc':'Reporte PDF con clasificación de riesgos, PoC y pasos de remediación. Re-test gratuito incluido.','.hero-actions .button.primary':'Solicitar una llamada de alcance gratuita',
    '.hero-actions .button.gold[href="daniel_cv_new.pdf"]':'Ver CV original',
    '.hero-actions .button.gold[href="htb-academy-student-transcript.pdf"]':'Descargar transcript',
    '.quick-stats li:nth-child(1) span':'Paths HTB completados',
    '.quick-stats li:nth-child(2) span':'Objetivos comprometidos',
    '.quick-stats li:nth-child(3) span':'Ranking HTB',
    
    
    '.avail-text':'Disponible para proyectos',

    // ── Terminal ──
    '.terminal-label':'daniel@portfolio:~$ ./escaneo_perfil',
    '.status-grid div:nth-child(1) span':'Estado',
    '.status-grid div:nth-child(1) strong':'ACTIVO',
    '.status-grid div:nth-child(2) span':'Enfoque',
    '.status-grid div:nth-child(2) strong':'PENTEST',
    '.status-grid div:nth-child(3) span':'Modo',
    '.status-grid div:nth-child(3) strong':'REMOTO',
    '.status-grid div:nth-child(4) span':'Cobertura',
    '.status-grid div:nth-child(4) strong':'WEB / RED / SIS','.status-grid div:nth-child(5) span':'Disponibilidad','.status-grid div:nth-child(5) strong':'ABIERTO','.status-grid div:nth-child(6) span':'Idiomas','.status-grid div:nth-child(6) strong':'ES / EN',

    // ── Experience ──
    '#experience .section-heading .section-tag':'[ EXPERIENCIA ]',
    '#experience .section-heading h3':'Formación y Experiencia',
    
    
    
    
    
    
    
    
    
    
    '#experience .timeline-item:nth-child(1) .role':'Desarrollador Full-Stack y Especialista en Seguridad · Dic 2025 – Abr 2026',
    '#experience .timeline-item:nth-child(1) .detail-list li:nth-child(1)':'Desarrollo de aplicaciones web con PHP, JavaScript y Node.js con seguridad integrada desde el inicio.',
    '#experience .timeline-item:nth-child(1) .detail-list li:nth-child(2)':'Seguridad de redes y aplicaciones — hardening, evaluaciones de vulnerabilidades y decisiones de arquitectura segura.',
    '#experience .timeline-item:nth-child(1) .detail-list li:nth-child(3)':'Administracion de servidores Linux — despliegue, configuracion y mantenimiento de entornos de produccion.',
    '#experience .timeline-item:nth-child(2) .role':'Entrenamiento en Seguridad Ofensiva · 2025',
    '#experience .timeline-item:nth-child(2) .detail-list li:nth-child(1)':'Completado el path CPTS — metodologia completa de pentesting para web, redes y Active Directory.',
    '#experience .timeline-item:nth-child(2) .detail-list li:nth-child(2)':'Tecnicas avanzadas de explotacion web del lado del servidor y del cliente a traves del path CWEE.',
    '#experience .timeline-item:nth-child(2) .detail-list li:nth-child(3)':'Entrenamiento en alcance, metodologia y documentacion profesional de engagements.',
    
    
    
    

    // ── Skills ──







    // ── Certifications ──
    '#certifications article:nth-child(1) .section-tag':'[ EDUCACION / CERTIFICACIONES ]',
    
    
    '#certifications .training-section:nth-of-type(1) .section-tag':'[ Paths HTB de Job Role y Skills Completados ]',
    '.path-card:nth-child(1) span:last-child':'Reconocimiento web, explotacion, APIs e informes profesionales.',
    '.path-card:nth-child(2) span:last-child':'Metodologia completa: recon, explotacion, post-explotacion, movimiento lateral e informes.',
    '.path-card:nth-child(3) span:last-child':'Deteccion de amenazas, DFIR, respuesta a incidentes y procedimientos SOC.',
    '.path-card:nth-child(4) span:last-child':'Fundamentos practicos que cubren disciplinas tanto ofensivas como defensivas.','.path-card:nth-child(5) strong':'Enumeracion de Active Directory','.path-card:nth-child(5) span:last-child':'Tecnicas de enumeracion de Active Directory en profundidad, herramientas y mapeo de superficie de ataque. Path de alta dificultad.','.path-card:nth-child(6) strong':'Fundamentos de Seguridad de la Informacion','.path-card:nth-child(6) span:last-child':'Conceptos esenciales de InfoSec: redes, criptografia, metodologia de pentesting y fundamentos de carrera.','.path-card:nth-child(7) strong':'Prerrequisitos de Analista SOC','.path-card:nth-child(7) span:last-child':'Conocimiento previo para operaciones SOC — fundamentos de seguridad y conceptos de analisis de amenazas.','.path-card:nth-child(8) strong':'Fundamentos de Sistemas Operativos','.path-card:nth-child(8) span:last-child':'Internos de Windows y Linux, administracion y hardening alineados con las mejores practicas de seguridad.','.path-card:nth-child(9) strong':'Escalacion de Privilegios Local','.path-card:nth-child(9) span:last-child':'Tecnicas de escalacion de privilegios manuales y asistidas por herramientas en sistemas Windows y Linux.','.path-card:nth-child(10) strong':'Introduccion a la Explotacion de Binarios','.path-card:nth-child(10) span:last-child':'Buffer overflows, shellcode y scripting de exploits. Path de alta dificultad.','.path-card:nth-child(11) strong':'Arsenal Basico de Herramientas','.path-card:nth-child(11) span:last-child':'Herramientas fundamentales de seguridad ofensiva y su aplicacion practica en distintos escenarios.','.path-card:nth-child(12) strong':'Comenzando en Hack The Box','.path-card:nth-child(12) span:last-child':'Primera maquina HTB guiada — conectando el conocimiento de la academia con labs del mundo real.',
    '.cert-group:nth-child(1) .subsection-label':'Estudios externos de ciberseguridad',
    
    
    

    // ── About ──
    '#about article:nth-child(1) .section-tag':'[ SOBRE MI ]',

    '#about article:nth-child(1) p:nth-of-type(2)':'Empecé como desarrollador full-stack. Ese contexto cambia cómo hago las pruebas — entiendo cómo se construyen las aplicaciones y sé dónde los desarrolladores dejan brechas. Combino eso con entrenamiento en seguridad ofensiva: explotación web, ataques a Active Directory, pivoting en redes y escalada de privilegios. Cada engagement termina con un reporte que tu equipo puede ejecutar de inmediato.',
    
    

        
    
    
    
    
    
    
    // ── Contact ──
    '#services-tag':'[ SERVICIOS ]','#services-heading':'Servicios','#services-copy':'Proyectos remotos, entregables claros, hallazgos que tu equipo puede corregir.','#svc-web-title':'Pentest de Aplicación Web','#svc-web-desc':'Encuentra vulnerabilidades explotables en tu aplicación antes de una brecha. Testing manual alineado con OWASP con un reporte que tu equipo puede ejecutar de inmediato.','#svc-ad-title':'Pentest de Active Directory','#svc-ad-desc':'Identifica rutas de ataque en tu red interna antes que un actor de amenaza. Mapeo con BloodHound, simulación de ataques de credenciales y una hoja de ruta de remediación clara.','#svc-va-desc':'Escaneo automatizado + manual de tu superficie de ataque con hallazgos validados y un reporte de remediación priorizado. Punto de entrada de menor costo antes de un pentest completo.','#svc-ai-desc':'Identifica riesgos de prompt injection, fuga de datos y manipulación de modelos en tus aplicaciones con IA antes de que lleguen a producción.','.service-cta':'Solicitar cotización →','#qc-main-cta':'Reservar llamada de alcance gratis →','#quote-heading':'Conoce el precio en 60 segundos','#quote-copy':'Completa los detalles para obtener un rango de precio al instante. Se enviará una propuesta formal después de la llamada de alcance.','#ql-service':'Servicio','#ql-scope':'Tamaño del alcance','#ql-complexity':'Complejidad','#ql-tbox':'Tipo de testing','#ql-addons':'Complementos','#contact .section-tag':'[ CONTACTO ]',
    '#contact h3':'Contáctame',
    '#cg-profiles':'Perfiles online','.contact-intro':'Disponible para proyectos remotos en todo el mundo. Respondo en menos de 24h. La primera llamada es gratuita — definimos alcance, cronograma y compatibilidad antes de cualquier acuerdo.',
    
    
    '.contact-card-phone-title':'Telefono',
    '.contact-card-phone-copy':'Llamada directa — respuesta inmediata',
    '.cg-li-title':'LinkedIn',
    '.cg-li-desc':'Perfil profesional y red de contactos',
    '.cg-gh-title':'GitHub',
    '.cg-gh-desc':'Codigo, proyectos y huella tecnica',

    // ── Footer ──
    'footer a[href="#main"]':'↑ Volver arriba',

    // ── Contact form ──
    '.contact-form-card .section-tag':'[ ENVIAR MENSAJE ]',
    '.cf-heading':'Mensaje directo',
    'label[for="cf-name"]':'Nombre',
    'label[for="cf-email"]':'Correo',
    'label[for="cf-message"]':'Mensaje',
    '.cf-btn-text':'Enviar mensaje'
  },
  placeholders:{
    '#cf-name':'Tu nombre',
    '#cf-email':'tu@correo.com',
    '#cf-message':'Describe el proyecto o engagement...'
  },
  formMessages:{
    requiredFields:'Por favor completa todos los campos.',
    invalidEmail:'Por favor ingresa un correo válido.',
    success:'✓ Mensaje enviado. Te respondo en menos de 24 horas.',
    submitFailed:'Error al enviar. Por favor intenta de nuevo.',
    networkError:'Error de red. Intenta de nuevo o usa el canal de correo.'
  },
  terminalLines:[
    '> Enumerando modulos de experiencia...','> Paths HTB completados: 12','> Objetivos comprometidos: 658','> Ranking: Top 1%','> Enfoque: seguridad web, de red y enterprise','> Objetivo: reducir riesgo explotable'
  ]
}}

// DOM references
const langButtons = document.querySelectorAll('[data-lang-toggle]');
const metaDescription = document.querySelector('meta[name="description"]');
const ogTitle = document.querySelector('meta[property="og:title"]');
const ogDescription = document.querySelector('meta[property="og:description"]');
const ogLocale = document.querySelector('meta[property="og:locale"]');

let currentLocale = localStorage.getItem('portfolio-lang') || 'en';
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let terminalTimer = null;

function setText(selector, value) {
  const node = document.querySelector(selector);
  if (node) node.textContent = value;
}

// Terminal animation — single implementation
function startTerminal(locale) {
  const stream = document.querySelector('.terminal-stream');
  if (!stream) return;
  const lines = translations[locale] && translations[locale].terminalLines;
  if (!lines) return;
  if (terminalTimer) { clearInterval(terminalTimer); terminalTimer = null; }
  let index = 0;
  function render() {
    stream.replaceChildren();
    for (let i = 0; i < 4; i++) {
      var pre = document.createElement('pre');
      pre.textContent = lines[(index + i) % lines.length];
      stream.appendChild(pre);
    }
    index = (index + 1) % lines.length;
  }
  render();
  if (!prefersReducedMotion) terminalTimer = setInterval(render, 3000);
}

// Locale
function applyLocale(locale) {
  const copy = translations[locale] || translations.en;
  Object.entries(copy.selectors).forEach(function(entry) { setText(entry[0], entry[1]); });
  if (copy.placeholders) {
    Object.entries(copy.placeholders).forEach(function(entry) {
      var node = document.querySelector(entry[0]);
      if (node) node.placeholder = entry[1];
    });
  }
  document.documentElement.lang = locale === 'es' ? 'es' : 'en';
  document.title = copy.documentTitle;
  if (metaDescription) metaDescription.setAttribute('content', copy.metaDescription);
  if (ogTitle) ogTitle.setAttribute('content', copy.ogTitle);
  if (ogDescription) ogDescription.setAttribute('content', copy.ogDescription);
  if (ogLocale) ogLocale.setAttribute('content', locale === 'es' ? 'es_ES' : 'en_US');
  langButtons.forEach(function(btn) {
    var active = btn.dataset.langToggle === locale;
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-pressed', active ? 'true' : 'false');
  });
  startTerminal(locale);
  localStorage.setItem('portfolio-lang', locale);
}

langButtons.forEach(function(btn) {
  btn.addEventListener('click', function() {
    currentLocale = btn.dataset.langToggle || 'en';
    applyLocale(currentLocale);
  });
});

applyLocale(currentLocale);

// Auto-update copyright year
(function() { var el = document.getElementById('cy'); if (el) el.textContent = new Date().getFullYear(); }());

// Restore obfuscated contact links from data attributes
(function() {
  document.querySelectorAll('[data-contact]').forEach(function(el) {
    var decoded = '';
    try { decoded = atob(el.dataset.contact || ''); } catch(e) { return; }
    if (decoded.startsWith('tel:')) {
      // Phone: native dialer is correct on mobile
      el.href = decoded;
    } else {
      // Email: use clipboard — avoids OS mailto: / login redirects
      el.setAttribute('href', '#');
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', 'Copy email address to clipboard');
      var email = decoded.replace(/^mailto:/, '');
      el.addEventListener('click', function(e) {
        e.preventDefault();
        var toast = document.getElementById('copy-toast');
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(email).then(function() {
            if (toast) { toast.textContent = '✓ Email copied: ' + email; toast.classList.add('show'); setTimeout(function(){ toast.classList.remove('show'); }, 3000); }
          }).catch(function() {
            // Fallback: show email inline
            if (toast) { toast.textContent = email; toast.classList.add('show'); setTimeout(function(){ toast.classList.remove('show'); }, 5000); }
          });
        } else {
          if (toast) { toast.textContent = email; toast.classList.add('show'); setTimeout(function(){ toast.classList.remove('show'); }, 5000); }
        }
      });
    }
  });
}());
// Contact form — Formspree AJAX handler
(function() {
  var form = document.getElementById('contact-form');
  var btn  = document.getElementById('cf-submit');
  var status = document.getElementById('cf-status');
  if (!form || !btn || !status) return;

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    if (btn.disabled) return;

    // Client-side validation
    var name    = form.querySelector('#cf-name').value.trim();
    var email   = form.querySelector('#cf-email').value.trim();
    var message = form.querySelector('#cf-message').value.trim();
    var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    var msgs = (translations[currentLocale] || translations.en).formMessages || {};
    if (!name || !email || !message) {
      status.textContent = msgs.requiredFields || 'Please fill in all fields.';
      status.className = 'cf-status error';
      return;
    }
    if (!emailRe.test(email)) {
      status.textContent = msgs.invalidEmail || 'Please enter a valid email address.';
      status.className = 'cf-status error';
      return;
    }

    // Submit
    btn.classList.add('loading');
    btn.disabled = true;
    status.textContent = '';
    status.className = 'cf-status';

    var data = new FormData(form);
    fetch(form.action, {
      method: 'POST',
      body: data,
      headers: { 'Accept': 'application/json' }
    })
    .then(function(res) {
      btn.classList.remove('loading');
      btn.disabled = false;
      if (res.ok) {
        status.textContent = ((translations[currentLocale]||translations.en).formMessages||{}).success||'✓ Message sent!';
        status.className = 'cf-status success';
        form.reset();
      } else {
        return res.json().then(function(data) {
          var msgs2=(translations[currentLocale]||translations.en).formMessages||{};
          var msg = (data&&data.errors)?data.errors.map(function(e){return e.message;}).join(', '):(msgs2.submitFailed||'Submission failed.');
          status.textContent = msg;
          status.className = 'cf-status error';
        });
      }
    })
    .catch(function() {
      btn.classList.remove('loading');
      btn.disabled = false;
      status.textContent=((translations[currentLocale]||translations.en).formMessages||{}).networkError||'Network error.';
      status.className = 'cf-status error';
    });
  });
}());

// Scroll reveal — fade+slide cards and elements into view
(function() {
  if (!window.IntersectionObserver || prefersReducedMotion) return;
  var els = [];
  document.querySelectorAll('.card, .mini-card, .cert-item, .resource-card, .social-link').forEach(function(el) {
    if (!el.closest('.hero')) {
      el.classList.add('reveal');
      els.push(el);
    }
  });
  var io = new IntersectionObserver(function(entries) {
    // Group by parent to stagger siblings
    var groups = new Map();
    entries.forEach(function(e) {
      if (!e.isIntersecting) return;
      var p = e.target.parentElement || document.body;
      if (!groups.has(p)) groups.set(p, []);
      groups.get(p).push(e.target);
    });
    groups.forEach(function(siblings) {
      siblings.forEach(function(el, i) {
        if (i > 0 && i <= 3) el.setAttribute('data-delay', i);
        el.classList.add('is-visible');
        // Also trigger section-tag scan animation
        var tag = el.querySelector('.section-tag');
        if (tag) tag.classList.add('tag-animate');
        io.unobserve(el);
      });
    });
  }, { threshold: 0.05, rootMargin: '0px 0px -20px 0px' });
  els.forEach(function(el) { io.observe(el); });
}());

// Animated stat counters for quick-stats numbers
(function() {
  if (!window.IntersectionObserver || prefersReducedMotion) return;
  document.querySelectorAll('.quick-stats strong').forEach(function(el) {
    var raw = el.textContent.trim();
    var num = parseInt(raw, 10);
    if (isNaN(num)) return; // Skip "Top 1%" etc.
    el.textContent = '0';
    var done = false;
    var io = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) {
        if (!e.isIntersecting || done) return;
        done = true;
        io.unobserve(e.target);
        var start = null;
        var duration = num > 100 ? 1400 : 900;
        function step(ts) {
          if (!start) start = ts;
          var p = Math.min((ts - start) / duration, 1);
          var v = Math.round((1 - Math.pow(1 - p, 3)) * num);
          e.target.textContent = v;
          if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      });
    }, { threshold: 0.6 });
    io.observe(el);
  });
}());

function safeExecute(fn, fallback, context) {
  try { return fn(); }
  catch (e) { console.error('[Error in ' + (context || '?') + ']:', e); if (fallback) fallback(); return null; }
}

// Scroll progress
function updateScrollProgress() {
  safeExecute(function() {
    const bar = document.querySelector('.progress-bar');
    if (!bar) return;
    const scrollable = document.documentElement.scrollHeight - window.innerHeight;
    const pct = scrollable > 0 ? Math.min(100, Math.max(0, window.pageYOffset / scrollable * 100)) : 0;
    bar.style.width = pct + '%';
  }, null, 'Scroll Progress');
}

// Active nav highlight
function updateActiveNav() {
  safeExecute(function() {
    const sections = document.querySelectorAll('main section[id]');
    const navLinks = document.querySelectorAll('.topnav a');
    if (!sections.length || !navLinks.length) return;
    let current = '';
    const pos = window.pageYOffset + 100;
    sections.forEach(function(sec) {
      if (pos >= sec.offsetTop && pos < sec.offsetTop + sec.offsetHeight) current = sec.id;
    });
    navLinks.forEach(function(link) {
      link.classList.remove('active');
      if (link.getAttribute('href') === '#' + current) link.classList.add('active');
    });
  }, null, 'Active Nav');
}

// Smooth scroll for nav links
document.querySelectorAll('.topnav a').forEach(function(a) {
  a.addEventListener('click', function(e) {
    const href = this.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const target = document.querySelector(href);
      if (target) target.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'start' });
    }
  });
});

window.addEventListener('scroll', function() {
  updateScrollProgress();
  updateActiveNav();
}, { passive: true });

window.addEventListener('DOMContentLoaded', function() {
  updateScrollProgress();
  updateActiveNav();
});

window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', function() {
  location.reload();
});

// Back to top
(function() {
  const btn = document.querySelector('.back-to-top');
  if (!btn) return;
  window.addEventListener('scroll', function() {
    btn.classList.toggle('visible', window.pageYOffset > 400);
  }, { passive: true });
  btn.addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
  });
}());





// Service Worker registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js').catch(function() {});
  });
}


// ── HAMBURGER MENU ────────────────────────────
(function() {
  var topbar = document.getElementById('topbar');
  var btn = topbar && topbar.querySelector('.nav-toggle');
  if (!topbar || !btn) return;
  var links = topbar.querySelectorAll('.topnav a');

  function close() {
    topbar.classList.remove('nav-open');
    btn.setAttribute('aria-expanded', 'false');
  }
  btn.addEventListener('click', function() {
    var open = topbar.classList.toggle('nav-open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  links.forEach(function(a) { a.addEventListener('click', close); });
  document.addEventListener('click', function(e) {
    if (!topbar.contains(e.target)) close();
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') close();
  });
}());

// ── TERMINAL TOGGLE (mobile) ──────────────────
(function() {
  var terminal = document.querySelector('.hero-panel.terminal');
  var btn = terminal && terminal.querySelector('.terminal-toggle');
  if (!terminal || !btn) return;

  function setOpen(open) {
    terminal.classList.toggle('is-open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  // Collapsed by default on mobile
  setOpen(window.innerWidth > 767);
  btn.addEventListener('click', function() {
    setOpen(!terminal.classList.contains('is-open'));
  });
}());



/* ── Konami Code + Matrix Rain Easter Egg ── */
(function () {
  var KONAMI = ['ArrowUp','ArrowUp','ArrowDown','ArrowDown','ArrowLeft','ArrowRight','ArrowLeft','ArrowRight','b','a'];
  var idx = 0;

  document.addEventListener('keydown', function(e) {
    var k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (k === KONAMI[idx]) {
      idx++;
      if (idx === KONAMI.length) { idx = 0; triggerMatrix(); }
    } else {
      idx = k === KONAMI[0] ? 1 : 0;
    }
  });

  function triggerMatrix() {
    // Overlay
    var overlay = document.createElement('div');
    overlay.id = 'matrix-overlay';
    overlay.style.cssText = [
      'position:fixed','inset:0','z-index:9999',
      'background:#000','display:flex',
      'flex-direction:column','align-items:center',
      'justify-content:center','cursor:pointer'
    ].join(';');

    // Canvas
    var canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%';
    overlay.appendChild(canvas);

    // Access Granted message
    var msg = document.createElement('div');
    msg.style.cssText = [
      'position:relative','z-index:2','text-align:center',
      'font-family:"JetBrains Mono",monospace','color:#00ff41',
      'text-shadow:0 0 20px #00ff41,0 0 40px #00ff41',
      'animation:glitch 0.4s infinite alternate'
    ].join(';');
    msg.innerHTML = [
      '<div style="font-size:clamp(2rem,8vw,4rem);font-weight:700;letter-spacing:0.15em;">ACCESS GRANTED</div>',
      '<div style="font-size:clamp(0.8rem,2vw,1.1rem);margin-top:16px;opacity:0.8;">Welcome, ' + (navigator.platform || 'Unknown') + ' operator</div>',
      '<div style="font-size:clamp(0.7rem,1.5vw,0.9rem);margin-top:8px;opacity:0.6;">[ click or press ESC to exit ]</div>'
    ].join('');
    overlay.appendChild(msg);

    // Add glitch keyframes once
    if (!document.getElementById('matrix-style')) {
      var st = document.createElement('style');
      st.id = 'matrix-style';
      st.textContent = '@keyframes glitch{0%{text-shadow:0 0 20px #00ff41,0 0 40px #00ff41;transform:translate(0)}50%{text-shadow:-2px 0 #ff0000,2px 0 #0000ff,0 0 30px #00ff41;transform:translate(-1px,1px)}100%{text-shadow:2px 0 #ff0000,-2px 0 #0000ff,0 0 20px #00ff41;transform:translate(1px,-1px)}}';
      document.head.appendChild(st);
    }

    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';

    // Matrix rain
    var ctx = canvas.getContext('2d');
    function resize() {
      canvas.width  = overlay.offsetWidth;
      canvas.height = overlay.offsetHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    var cols   = Math.floor(canvas.width / 16);
    var drops  = Array.from({length: cols}, function() { return Math.random() * -50 | 0; });
    var CHARS  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*<>/\\|[]{}アイウエオカキクケコサシスセソタチツテトナニヌネノ';

    var raf;
    function draw() {
      ctx.fillStyle = 'rgba(0,0,0,0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = '14px "JetBrains Mono", monospace';
      for (var i = 0; i < drops.length; i++) {
        var ch = CHARS[Math.random() * CHARS.length | 0];
        var bright = Math.random() > 0.95;
        ctx.fillStyle = bright ? '#ffffff' : '#00ff41';
        ctx.fillText(ch, i * 16, drops[i] * 16);
        if (drops[i] * 16 > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
      raf = requestAnimationFrame(draw);
    }
    draw();

    function close() {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      document.body.style.overflow = '';
    }

    overlay.addEventListener('click', close);
    document.addEventListener('keydown', function esc(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc); }
    });

    // Auto-close after 15s
    setTimeout(close, 15000);
  }
}());

// 3D Tilt effect on cards
(function() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if ('ontouchstart' in window) return;

  var STRENGTH = 7;

  function initTilt(card) {
    var glare = document.createElement('div');
    glare.style.cssText = 'position:absolute;inset:0;border-radius:inherit;pointer-events:none;opacity:0;transition:opacity 200ms ease;z-index:1';
    card.appendChild(glare);

    card.style.transformStyle = 'preserve-3d';
    card.style.transition = 'transform 100ms ease';
    card.style.willChange = 'transform';

    function onMove(e) {
      var rect = card.getBoundingClientRect();
      var x = (e.clientX - rect.left) / rect.width  - 0.5;
      var y = (e.clientY - rect.top)  / rect.height - 0.5;
      var rotY =  x * STRENGTH * 2;
      var rotX = -y * STRENGTH * 2;
      card.style.transform = 'perspective(900px) rotateX('+rotX+'deg) rotateY('+rotY+'deg) scale3d(1.012,1.012,1.012)';
      var gx = Math.round((x + 0.5) * 100);
      var gy = Math.round((y + 0.5) * 100);
      glare.style.background = 'radial-gradient(circle at '+gx+'% '+gy+'%, rgba(255,255,255,0.035), transparent 65%)';
      glare.style.opacity = '1';
    }

    function onLeave() {
      card.style.transition = 'transform 500ms ease';
      card.style.transform = 'perspective(900px) rotateX(0deg) rotateY(0deg) scale3d(1,1,1)';
      glare.style.opacity = '0';
    }

    card.addEventListener('mousemove', onMove);
    card.addEventListener('mouseleave', onLeave);
  }

  function attachAll() {
    document.querySelectorAll('.card').forEach(function(c) {
      if (c.closest('.hero') || c.classList.contains('terminal')) return;
      initTilt(c);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachAll);
  } else {
    attachAll();
  }
}());



/* ── Custom Crosshair Cursor ── */
(function() {
  if (!window.matchMedia('(pointer: fine)').matches) return;
  var dot  = document.querySelector('.cursor-dot');
  var ring = document.querySelector('.cursor-ring');
  if (!dot || !ring) return;

  var mx = -200, my = -200, rx = -200, ry = -200;

  document.addEventListener('mousemove', function(e) {
    mx = e.clientX; my = e.clientY;
    dot.style.left = mx + 'px';
    dot.style.top  = my + 'px';
  });

  (function animateRing() {
    rx += (mx - rx) * 0.14;
    ry += (my - ry) * 0.14;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(animateRing);
  }());

  var hoverTargets = 'a,button,[role="button"],input,textarea,select,label,.mini-card,.transcript-featured,.cert-item,.social-link,.lang-button';
  document.addEventListener('mouseover', function(e) {
    if (e.target.closest(hoverTargets)) document.body.classList.add('cursor-hovering');
  });
  document.addEventListener('mouseout', function(e) {
    if (e.target.closest(hoverTargets)) document.body.classList.remove('cursor-hovering');
  });
  document.addEventListener('mousedown', function() { document.body.classList.add('cursor-clicking'); });
  document.addEventListener('mouseup',   function() { document.body.classList.remove('cursor-clicking'); });
  document.addEventListener('mouseleave', function() { dot.style.opacity='0'; ring.style.opacity='0'; });
  document.addEventListener('mouseenter', function() { dot.style.opacity='1'; ring.style.opacity='1'; });
}());

/* ── Quote Calculator v4 ─────────────────────────────────── */
(function () {
  'use strict';

  var PRICES = {
    pentest_web: { name:'Web App Pentest',  base:[3000,6000], scope:{small:1.0,medium:1.55,large:2.3}, cplx:{low:1.0,medium:1.45,high:2.0}, tbox:{black:1.0,grey:1.2,white:1.45} },
    pentest_ad:     { name:'Active Directory',    base:[5000,9500], scope:{small:1.0,medium:1.4, large:2.0}, cplx:{low:1.0,medium:1.35,high:1.85}, tbox:{black:1.0,grey:1.2,white:1.45} },
    vuln_assessment: { name:'Vuln Assessment',      base:[500,1500],   scope:{small:1.0,medium:1.3, large:1.8}, cplx:{low:1.0,medium:1.2, high:1.5},  tbox:{black:1.0,grey:1.15,white:1.35} },
    pentest_ai:      { name:'AI / LLM Assessment', base:[2000,4500],  scope:{small:1.0,medium:1.4, large:2.0}, cplx:{low:1.0,medium:1.35,high:1.8},  tbox:{black:1.0,grey:1.2,white:1.45} }
  };
  var ADDONS = { urgent:{label:'Rush',pct:.25} };
  var SCOPE_LABELS_EN = { small:'Small · 1–5', medium:'Medium · 6–15', large:'Large · 15+' };
  var SCOPE_LABELS_ES = { small:'Pequeño · 1–5', medium:'Mediano · 6–15', large:'Grande · 15+' };
  var CPLX_LABELS_EN  = { low:'Standard', medium:'Custom', high:'Enterprise' };
  var CPLX_LABELS_ES  = { low:'Estándar', medium:'Personalizado', high:'Empresarial' };
  var TBOX_LABELS_EN  = { black:'Black-box', grey:'Grey-box', white:'White-box' };
  var TBOX_LABELS_ES  = { black:'Caja negra', grey:'Grey-box', white:'Caja blanca' };
  var SCOPE_SETS = {
    pentest_web:      { small:'1–5 pages/endpoints', medium:'6–15 pages/endpoints', large:'15+ pages/endpoints' },
    pentest_ad:       { small:'1–3 hosts',           medium:'4–10 hosts',           large:'10+ hosts'           },
    vuln_assessment:  { small:'1–10 IPs/assets',     medium:'11–50 IPs/assets',     large:'50+ IPs/assets'      },
    pentest_ai:       { small:'1 model/integration',     medium:'2–4 models',           large:'5+ models'           }
  };

  function fmt(n) { return '$' + Math.round(n).toLocaleString('en-US'); }

  function recalc() {
    var SCOPE_LABELS = (typeof currentLocale!=='undefined'&&currentLocale==='es') ? SCOPE_LABELS_ES : SCOPE_LABELS_EN;
    var CPLX_LABELS  = (typeof currentLocale!=='undefined'&&currentLocale==='es') ? CPLX_LABELS_ES  : CPLX_LABELS_EN;
    var TBOX_LABELS  = (typeof currentLocale!=='undefined'&&currentLocale==='es') ? TBOX_LABELS_ES  : TBOX_LABELS_EN;
    var svcBtn   = document.querySelector('.qc-svc-card.active');
    var scopeBtn = document.querySelector('.qc-toggle[data-scope].active');
    var cplxBtn  = document.querySelector('.qc-toggle[data-cplx].active');
    var tboxBtn  = document.querySelector('.qc-toggle[data-tbox].active');
    if (!svcBtn || !scopeBtn || !cplxBtn) return;

    var svc = svcBtn.dataset.svc, scope = scopeBtn.dataset.scope, cplx = cplxBtn.dataset.cplx, tbox = tboxBtn ? tboxBtn.dataset.tbox : 'black';
    var p = PRICES[svc]; if (!p) return;
    var mn = p.base[0] * (p.scope[scope]||1) * (p.cplx[cplx]||1) * (p.tbox[tbox]||1);
    var mx = p.base[1] * (p.scope[scope]||1) * (p.cplx[cplx]||1) * (p.tbox[tbox]||1);

    var addonMult = 1, addonTags = [];
    document.querySelectorAll('.qc-chip.active').forEach(function(btn) {
      var a = ADDONS[btn.dataset.addon]; if (a) { addonMult += a.pct; addonTags.push(a.label); }
    });
    mn *= addonMult; mx *= addonMult;

    var el = function(id) { return document.getElementById(id); };
    if (el('q-min')) el('q-min').textContent = fmt(mn);
    if (el('q-max')) el('q-max').textContent = fmt(mx);
    if (el('q-unit')) el('q-unit').textContent = 'USD' + (p.unit||'');
    if (el('qc-bar')) {
      var svcMax = p.base[1] * (p.scope['large']||1) * (p.cplx['high']||1) * 1.7;
      el('qc-bar').style.width = Math.min(92,Math.max(8,(mn / svcMax)*100)).toFixed(1)+'%';
    }
    var ss = SCOPE_SETS[svc];
    if (ss) {
      document.querySelectorAll('.qc-toggle[data-scope]').forEach(function(btn) {
        var s = btn.dataset.scope, small2 = btn.querySelector('small');
        if (small2 && ss[s]) small2.textContent = ss[s];
      });
    }
    if (el('qr-svc-name')) el('qr-svc-name').textContent = p.name;
    if (el('qr-scope')) el('qr-scope').textContent = SCOPE_LABELS[scope]||scope;
    if (el('qr-cplx')) el('qr-cplx').textContent = CPLX_LABELS[cplx]||cplx;
    if (el('qr-tbox')) el('qr-tbox').textContent = TBOX_LABELS[tbox]||tbox;
    var row = el('qr-addons-row'), tags = el('qr-addons-tags');
    if (row && tags) {
      if (addonTags.length) {
        tags.innerHTML = addonTags.map(function(t){return '<span class="qc-addon-tag">'+t+'</span>';}).join('');
        row.style.display = 'flex';
      } else { row.style.display = 'none'; }
    }
  }

  function activate(group, clicked) {
    document.querySelectorAll(group).forEach(function(b){ b.classList.remove('active'); });
    clicked.classList.add('active');
    if (group === '.qc-svc-card') {
  
    }
    recalc();
  }

  function ready(fn) {
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  ready(function() {
    document.querySelectorAll('.qc-svc-card').forEach(function(btn) {
      btn.addEventListener('click', function() { activate('.qc-svc-card', btn); });
    });
    document.querySelectorAll('.qc-toggle[data-scope]').forEach(function(btn) {
      btn.addEventListener('click', function() { activate('.qc-toggle[data-scope]', btn); });
    });
    document.querySelectorAll('.qc-toggle[data-cplx]').forEach(function(btn) {
      btn.addEventListener('click', function() { activate('.qc-toggle[data-cplx]', btn); });
    });
    document.querySelectorAll('.qc-toggle[data-tbox]').forEach(function(btn) {
      btn.addEventListener('click', function() { activate('.qc-toggle[data-tbox]', btn); });
    });
    document.querySelectorAll('.qc-chip').forEach(function(btn) {
      btn.addEventListener('click', function() { btn.classList.toggle('active'); recalc(); });
    });
    recalc();

    // service-cta cards on the services section pre-select calc
    document.querySelectorAll('.service-cta[data-select]').forEach(function(link) {
      link.addEventListener('click', function() {
        var svc = link.dataset.select;
        var card = document.querySelector('.qc-svc-card[data-svc="'+svc+'"]');
        if (card) { activate('.qc-svc-card', card); }
      });
    });

    // CTA button pre-fills the contact form
    var mainCta = document.getElementById('qc-main-cta');
    if (mainCta) {
      mainCta.addEventListener('click', function() {
        var svcBtn = document.querySelector('.qc-svc-card.active');
        var minEl = document.getElementById('q-min');
        var maxEl = document.getElementById('q-max');
        var msg = document.getElementById('cf-message');
        if (msg && svcBtn && minEl && maxEl) {
          var svcName = (PRICES[svcBtn.dataset.svc]||{}).name || svcBtn.dataset.svc;
          if (typeof currentLocale!=='undefined' && currentLocale==='es') {
            msg.value = 'Me interesa el servicio de ' + svcName + ' (' + minEl.textContent + ' - ' + maxEl.textContent + ' USD). Por favor envíame una propuesta detallada.';
          } else {
            msg.value = 'I\'m interested in ' + svcName + ' (' + minEl.textContent + ' - ' + maxEl.textContent + ' USD). Please send me a detailed proposal.';
          }
        }
      });
    }
  });
})();

